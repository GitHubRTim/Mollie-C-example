﻿using System;
using System.Net;
using System.IO;
using System.Text;
using Newtonsoft.Json;        // Get this "Newtonsoft.Json" by loading a it from "Manage NuGet Packages" in Visual Studio 2015 (right click on your solution name)


// ThisC#  example shows how to send a transaction to Mollie with plain JSON
// Copy these files to your Visual studio development environment and use the debugger to see what is happening by tarting this form
// To Generate JSON you need to load the libraries from Newonsoft.Json in your Visual studio project. Find it in "Manage NuGet Packages" in Visual Studio 2015 (right click on your solution name)

// Very importandt is to TURN ON PAYMENT METHODS after you have created a Mollie account under Settings ==> Website Profiles:
// https://www.mollie.com/dashboard/settings/profiles   (Select payment methods) They do not need to be completed to test your interface.
// In Mollie you do not need to activate your account "Complete account" to run program tests


// Common error:
// The remote server returned an error: (401) Unauthorized.:   You do not have valid credentials test_Mut7BGvad8dQu6mrGvgtpxk2UuGVtE is not correct.

// Return message in JSON: Status: 422, title: Unprocessed entity. Detail:"Non-Existent body parameter \"first paramete name\" for this API call.
// This eror will happen if you did not specify a payment option in the mollie account settings.


namespace YourNamespace
{

    public partial class PayMollieTest : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["resultstring"] == null)
                Session["resultstring"] = "";

            TextBoxResult.Text = Session["resultstring"].ToString();
        }



        protected void ButtonPayMollie_Click(object sender, EventArgs e)
        {

            string result = "";
            string apilocation = "https://api.mollie.com/v2/payments";
            string authorization = "Bearer test_Mut7BGvad8dQu6mrGvgtpxk2UuGVtE";  // Replace with your own test id

            PaymentRequest PayRequest = new PaymentRequest();
            Amount amt = new Amount();
            amt.currency = "EUR";
            amt.value = "10.00";
            PayRequest.amount = amt;

            Metadata md = new Metadata();
            md.order_id = "12345";
            PayRequest.metadata = md;

            PayRequest.description = "Order #12345";
            PayRequest.redirectUrl = "http://localhost:2939/PayMollieTest.aspx";  // Change 2939 to your development port number
            PayRequest.webhookUrl = "https://m.yourside.com/Ordersuccess.aspx";


            string jsonmessage = JsonConvert.SerializeObject(PayRequest);
            byte[] buffer = Encoding.ASCII.GetBytes(jsonmessage);

            //------ Post ----
            HttpWebRequest WebReq = WebRequest.Create(apilocation) as HttpWebRequest;
            WebReq.Headers.Add("Authorization", authorization);
            WebReq.Method = "POST";
            WebReq.ContentType = "application/json";
            WebReq.ContentLength = buffer.Length;
            Stream PostData = WebReq.GetRequestStream();                              // We open a stream for writing the postvars
            PostData.WriteTimeout = 10000;                                            // 10 seconds
            PostData.Write(buffer, 0, buffer.Length);                                 // Now we write, and afterwards, we close. Closing is always important!
            PostData.Close();


            using (HttpWebResponse response = WebReq.GetResponse() as HttpWebResponse)
            {
                // Get the response stream   
                StreamReader reader = new StreamReader(response.GetResponseStream());

                // Read the whole contents and return as a string   
                result = reader.ReadToEnd();
                response.Close();                                // Must close the connection
            }

            PaymentResponse OrderObject = JsonConvert.DeserializeObject<PaymentResponse>(result);
           
            Session["resultstring"] = $"Received Message string: {result} \nCalled: " + OrderObject._links.checkout.href;

            Page.Response.Redirect(OrderObject._links.checkout.href);      



        }






        public class PaymentRequest                         // Data to initiate a new payment
        {
            public Amount amount { get; set; }
            public string description { get; set; }
            public string redirectUrl { get; set; }
            public string webhookUrl { get; set; }
            public Metadata metadata { get; set; }
        }



        public class PaymentResponse                       // Returned from the initiated payment request
        {
            public string resource { get; set; }
            public string id { get; set; }
            public string mode { get; set; }
            public DateTime createdAt { get; set; }
            public Amount amount { get; set; }
            public string description { get; set; }
            public object method { get; set; }
            public Metadata metadata { get; set; }
            public string status { get; set; }
            public bool isCancelable { get; set; }
            public DateTime expiresAt { get; set; }
            public object details { get; set; }
            public string profileId { get; set; }
            public string sequenceType { get; set; }
            public string redirectUrl { get; set; }
            public string webhookUrl { get; set; }
            public _Links _links { get; set; }
        }


        public class PaymentStatus                         // After webhook is called, check of payment was succesfull, fill this structure
        {
            public string resource { get; set; }
            public string id { get; set; }
            public string mode { get; set; }
            public DateTime createdAt { get; set; }
            public Amount amount { get; set; }
            public string description { get; set; }
            public object method { get; set; }
            public Metadata metadata { get; set; }
            public string status { get; set; }
            public bool isCancelable { get; set; }
            public DateTime expiresAt { get; set; }
            public string profileId { get; set; }
            public string sequenceType { get; set; }
            public string redirectUrl { get; set; }
            public string webhookUrl { get; set; }
            public _Links _links { get; set; }
        }

        //---------------------------------------------------------------------


        public class Amount
        {
            public string value { get; set; }
            public string currency { get; set; }
        }

        public class Metadata
        {
            public string order_id { get; set; }
        }

        public class _Links
        {
            public Self self { get; set; }
            public Checkout checkout { get; set; }
            public Documentation documentation { get; set; }
        }

        public class Self
        {
            public string href { get; set; }
            public string type { get; set; }
        }

        public class Checkout
        {
            public string href { get; set; }
            public string type { get; set; }
        }

        public class Documentation
        {
            public string href { get; set; }
            public string type { get; set; }
        }

        //---------------------------------------------------------------------





    }
}


